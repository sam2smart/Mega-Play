
						<?php
		if(isset($_POST['sub']))
					{
						
						$check1 = $_POST['check1'];
						$check2 = $_POST['check2'];
						$check3 = $_POST['check3'];
						$phone = $_POST['phone'];
						$email = $_POST['email'];
						
						
						if(empty($check1))
						{
							echo "<script>alert('Empty field 1 !!!');</script>";
						}
						if(empty($check2))
						{
							echo "<script>alert('Empty field 2 !!!');</script>";
						}
						if(empty($check3))
						{
							echo "<script>alert('Empty field 3 !!!');</script>";
						}
						
						
			
						
						$stmt=$con->prepare("SELECT * FROM game WHERE check1=:check1 or check3=:check3");
						$stmt->execute(array(":check1"=>$check1,":check3"=>$check3));
						
						$vRow=$stmt->fetch(PDO::FETCH_ASSOC);
						$don = $vRow['check1'];
						echo "<script> alert('You Have $don !!!') </script>";
						
						if($check1 == $vRow['check1'] && $check2 == $vRow['check2'] && $check3 == $vRow['check3'] && $check4 == $vRow['check4'])
						{
							
							echo "<script> alert('You Have Inserted This Code Once !!!') </script>";
						}else{
							
							$add_sub_cat = $con->prepare("insert into game(check1,check2,check3,phone,email)values('$check1','$check2','$check3','$phone','$email')");;
							if($add_sub_cat->execute()){
									echo "<script>alert('Data Added successfully !!!');</script>";
									echo "<script>window.open('index.php?#form','_self');</script>";
								}
								else{
									echo "<script>alert('Data Not Added successfully !!!');</script>";
								}
							
						}
					}
		?>
                             <form action="" method="post" enctype="multipart/form-data">
								&nbsp;&nbsp;&nbsp;&nbsp;
								
								<div class="form-group">
			<input type="text" style="text-align: center; width: 20%; border-radius: 20px 20px;" class="form-controls" name="check1" min="0" max="99" required />
			<input type="text" style="text-align: center; width: 20%; border-radius: 20px 20px;" class="form-controls" name="check2" min="0" max="99" required />
			<input type="text" style="text-align: center; width: 20%; border-radius: 20px 20px;" class="form-controls" name="check3" min="0" max="99" required />
							
			<hr>
			</div><br>
								
								<input type="email" name="email" Placeholder="input Email" class="form-control" required><br>
								<input type="tel" name="phone" Placeholder="Phone" class="form-control" required><br>
								<button type="submit" name="sub" class="btn btn-success">PLAY</submit>
								
							</form> 