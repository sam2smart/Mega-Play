<?php

require_once('dbconfig.php');

class crud
{	

	private $db;
	
	public function __construct()
	{
		$database = new dataBos();
		$conn = $database->dbConnection();
		$this->db = $conn;
    }
	
	public function updatePay($pay,$iv_ip)
	{
		try
		{
		
			$stmt = $this->db->prepare("UPDATE investment SET withdraw=:pay WHERE invest_id=:iv_ip");
			$stmt->bindparam(":pay",$pay);
			$stmt->bindparam(":iv_ip",$iv_ip);
			
			
			if($stmt->execute())
			{
					echo "<script>window.open('home.php','_self');</script>";
			}
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}
	
	
	public function updateUser($fname,$lname,$uname,$uemail,$phone,$gent,$radd,$ref,$upass,$aupass,$newpass,$joind,$admin,$in_id)
	{
		try
		{
			$stmt = $this->db->prepare("UPDATE users SET fname=:fname, lname=:lname, user_name=:uname, user_email=:uemail, phone=:phone, gender=:gent, radd=:radd,
			ref=:ref, forget_pass=:aupass, user_pass=:upass, rem_pass=:newpass, joining_date=:joind, admin_a=:admin WHERE user_id=:in_id");
			$stmt->bindparam(":fname",$fname);
			$stmt->bindparam(":lname",$lname);
			$stmt->bindparam(":uname",$uname);
			$stmt->bindparam(":uemail",$uemail);
			$stmt->bindparam(":phone",$phone);
			$stmt->bindparam(":gent",$gent);
			$stmt->bindparam(":radd",$radd);
			$stmt->bindparam(":ref",$ref);
			$stmt->bindparam(":upass",$upass);
			$stmt->bindparam(":aupass",$aupass);
			$stmt->bindparam(":newpass",$newpass);
			$stmt->bindparam(":joind",$joind);
			$stmt->bindparam(":admin",$admin);
			$stmt->bindparam(":in_id",$in_id);
			if($stmt->execute())
			{
					echo "<script>window.open('home.php?users','_self');</script>";
			}
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}
	
	public function updateAdmin($adname,$ademail,$pass,$ad_id)
	{
		try
		{
			$new_password = password_hash($pass, PASSWORD_DEFAULT);
			
			$stmt = $this->db->prepare("UPDATE admin SET admin_name=:adname, admin_email=:ademail, password=:pass, ad_hint=:ad_hint WHERE ad_id=:ad_id");
			$stmt->bindparam(":adname",$adname);
			$stmt->bindparam(":ademail",$ademail);
			$stmt->bindparam(":pass",$new_password);
			$stmt->bindparam(":ad_hint",$pass);
			$stmt->bindparam(":ad_id",$ad_id);
			
			if($stmt->execute())
			{
					echo "<script>window.open('home.php?users','_self');</script>";
			}
			return true;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
		
	}
	
	public function updateInvestment($fname,$lname,$cur,$ref,$amount,$email,$phone,$int,$tot,$type,$disc,$date,$ddt,$mess,$in_id,$wid)
	{
		try
		{
			$stmt=$this->db->prepare("UPDATE investment SET fname=:fname, lname=:lname, currency=:cur, ref=:ref, amount=:amount, email=:email, phone=:phone, intrest=:int, total=:tot, 
			type=:type, discition=:disc, date=:date, due_date=:ddt, message=:mess, withdraw=:wid WHERE invest_id=:in_id");
			
			
			$stmt->bindparam(":fname",$fname);
			$stmt->bindparam(":lname",$lname);
			$stmt->bindparam(":cur",$cur);
			$stmt->bindparam(":ref",$ref);
			$stmt->bindparam(":amount",$amount);
			$stmt->bindparam(":email",$email);
			$stmt->bindparam(":phone",$phone);
			$stmt->bindparam(":int",$int);
			$stmt->bindparam(":tot",$tot);
			$stmt->bindparam(":type",$type);
			$stmt->bindparam(":disc",$disc);
			$stmt->bindparam(":date",$date);
			$stmt->bindparam(":ddt",$ddt);
			$stmt->bindparam(":mess",$mess);
			$stmt->bindparam(":wid",$wid);
			$stmt->bindparam(":in_id",$in_id);
			
			if($stmt->execute())
			{
				echo "<script>alert(Success !!!); </script>";
				echo "<script>window.open('home.php','_self');</script>";
			}
			
			return true;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();	
			return false;
		}
	}
	
	public function deleteVadate($in_id,$phone,$date)
	{
		$stmt = $this->db->prepare("DELETE FROM vadate WHERE vdate=:date");
		$stmt->bindparam(":date",$date);
		
		$stmt->execute();
		
		return true;
	}
	
	public function deleteInvestment($in_id,$phone,$date)
	{
		$stmt = $this->db->prepare("DELETE FROM investment WHERE invest_id=:id");
		$stmt->bindparam(":id",$in_id);
		
		if($stmt->execute())
		{
			echo "<script>alert('succeesful !!!');</script>";
			echo "<script>window.open('home.php','_self');</script>";
		}
		return true;
	}
	
	public function deleteUser($in_id)
	{
		$stmt = $this->db->prepare("DELETE FROM users WHERE user_id=:id");
		$stmt->bindparam(":id",$in_id);
		if($stmt->execute())
		{
			echo "<script>alert('succeesful !!!');</script>";
			echo "<script>window.open('home.php?users','_self');</script>";
		}
		return true;
	}
	
	public function updateId($tp,$iv_ip,$intr,$tota,$mess)
	{
		try{
		$stmt = $this->db->prepare("UPDATE investment SET type=:tp, intrest=:intr, total=:tota, message=:mess where invest_id = :iv_ip");
		
		$stmt->bindparam(":tp", $tp);
		$stmt->bindparam(":iv_ip", $iv_ip);
		$stmt->bindparam(":intr", $intr);
		$stmt->bindparam(":tota", $tota);
		$stmt->bindparam(":mess", $mess);
		
		$stmt->execute();	
			
		return $stmt;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	
	public function updatePart($tp,$iv_ip)
	{
		try{
		$stmt = $this->db->prepare("UPDATE partners SET type=:tp where part_id = :iv_ip");
		
		$stmt->bindparam(":tp", $tp);
		$stmt->bindparam(":iv_ip", $iv_ip);
		
		$stmt->execute();	
			
		return $stmt;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	
	
	public function partnerRecord($query)
	{
		$stmt = $this->db->prepare($query);
		$stmt->execute();
	
		if($stmt->rowCount()>0)
		{
			$i = 1;
			while($row=$stmt->fetch(PDO::FETCH_ASSOC))
			{
				?>
                <tr>
                <td><?php echo $i++; ?></td>
                <td><?php print($row['fname']); ?></td>
                <td><?php print($row['lname']); ?></td>
                <td><?php print($row['ref']); ?></td>
                <td><?php print($row['email']); ?></td>
                <td><?php print($row['phone']); ?></td>
                <td><?php print($row['currency']); ?></td>
                <td><?php print($row['amount']); ?></td>
                
				<form method="post" action="">
				<td>
					  <select type="text" name="tp" >
						<option value=""><?php echo $row['type']; ?></option>
						<option value="AP">AP</option>
						<option value="NA">NA</option>
					  </select>
					</td>
					<input type="hidden" name="uid" value="<?php echo $row['part_id']; ?>" >
					<td>
						<button name="sub" class="btn btn-primary"><i class="fa fa-save "></i></button>
					</td>
				</form>
				
               <td>
				   
					<button id="popup" onclick="div_show()">
						<?php echo "<img src=../../inc/$row[image] class='rounded-circle' alt='$row[fname]' width='30'>"; ?>
					</button>
					</td>
				 <td><?php print($row['jdate']); ?></td>
                <td align="center">
                <a href="home.php?euser=<?php print($row['user_id']); ?>"  class="btn btn-primary"><i class="fa fa-edit "></i></a>
                </td>
                <td align="center">
                <a href="home.php?duser=<?php print($row['user_id']); ?>"  class="btn btn-primary"><i class="fa fa-trash-o "></i></a>
                </td>
                </tr>
                <?php
			}
		}
		else
		{
			?>
            <tr>
            <td>Nothing here...</td>
            </tr>
            <?php
		}
		
	}

			
	/* paging */
	// Users Record
	public function userRecord($query)
	{
		$stmt = $this->db->prepare($query);
		$stmt->execute();
	
		if($stmt->rowCount()>0)
		{
			$i = 1;
			while($row=$stmt->fetch(PDO::FETCH_ASSOC))
			{
				?>
                <tr>
                <td><?php echo $i++; ?></td>
                <td><?php print($row['fname']); ?></td>
                <td><?php print($row['lname']); ?></td>
                <td><?php print($row['user_name']); ?></td>
                <td><?php print($row['user_email']); ?></td>
                <td><?php print($row['phone']); ?></td>
                <td><?php print($row['gender']); ?></td>
                <td>
				
				<div class="row">
							<div class="d-inline-block text-truncate" style="max-width: 130px;">
								<?php echo $row['radd']; ?>
						</div>
					</div>
				
				</td>
                <td><?php print($row['ref']); ?></td>
                <td>
					<div class="row">
						<div class="d-inline-block text-truncate" style="max-width: 130px;">
						<?php print($row['user_pass']); ?>
					</div>
				</td>
                <td><?php print($row['forget_pass']); ?></td>
                <td><?php print($row['rem_pass']); ?></td>
                <td><?php print($row['joining_date']); ?></td>
                <td><?php print($row['admin_a']); ?></td>
                <td align="center">
                <a href="home.php?euser=<?php print($row['user_id']); ?>"  class="btn btn-primary"><i class="fa fa-edit "></i></a>
                </td>
                <td align="center">
                <a href="home.php?duser=<?php print($row['user_id']); ?>"  class="btn btn-primary"><i class="fa fa-trash-o "></i></a>
                </td>
                </tr>
                <?php
			}
		}
		else
		{
			?>
            <tr>
            <td>Nothing here...</td>
            </tr>
            <?php
		}
		
	}
	
	//Investment Record.
	public function dataview($query)
	{
		$stmt = $this->db->prepare($query);
		$stmt->execute();
	$i = 1;
		if($stmt->rowCount()>0)
		{
			while($row=$stmt->fetch(PDO::FETCH_ASSOC))
			{
				$inve = $row['amount'];
				$pricee = 10/100*$inve;
				$tot = $pricee + $inve;
				
				$fname = $row['fname'];
				$lname = $row['lname'];
				$amount = $row['amount'];
				$date = $row['date'];
				$total = $row['total'];
				$ddate = $row['due_date'];
				
				
				
				//echo $fnamee;
		$messa = "This is a memorandom of understanding document between ".$fname." ".$lname." and Mostmerit Investment, for the Colaboration interest of 18% monthly interest over a principal investment of ".$amount." paid on the ".$date.". 
				An agreement to pay a total of ".$total." on the ".$ddate.". Attached with this MOU is an evidence of payment by ".$fname.' '.$lname.".
				";
		//echo $messa;
				?>
                <tr class="clickable-row" >
                   <td> <?php echo $i++; ?>   </td>
                   <td><?php echo $row['fname']; ?></td> 
                   <td><?php echo $row['lname']; ?></td> 
                   <td><?php echo $row['currency']; ?></td> 
				   <td> <?php echo $row['phone']; ?> </td>
				   <td><?php echo $row['email']; ?> </td>
				   <td><?php echo $row['ref']; ?> </td>
				   <td> <?php echo $row['amount']; ?> </td>
				    <form method="post" action="">
				   <td>
				   <?php echo $row['intrest']; ?> 
				   <input type="hidden" name="intr" value="<?php echo $pricee; ?>" >
				   </td>
				   <td>
						<?php echo $row['total']; ?> 
						<input type="hidden" name="tota" value="<?php echo $tot; ?>" >
					</td>
				   <td> 

				  
					<select type="text" name="tp" >
						<option value=""><?php echo $row['type']; ?></option>
						<option value="AP">AP</option>
						<option value="NA">NA</option>
					</select>
					<input type="hidden" name="uid" value="<?php echo $row['invest_id']; ?>" >
					<input type="hidden" name="mess" value="<?php echo $messa; ?>" >
					 </td>
					
					<td>
						<button name="sub" class="btn btn-primary"><i class="fa fa-save "></i></button>
					</td>
                    </form>
				  
				   <td>  <?php echo $row['discition']; ?> </td>
				   <td>
				   
					<button id="popup" onclick="div_show()">
						<?php echo "<img src=../../inc/$row[image] class='rounded-circle' alt='$row[fname]' width='100'>"; ?>
					</button>
					</td>
				   <td>  <?php echo $row['date']; ?> </td>
				   <td>  <?php echo $row['due_date']; ?> </td>
				   <td>
						<div class="row">
							<div class="d-inline-block text-truncate" style="max-width: 130px;">
								<?php echo $row['message']; ?>
						</div>
					</div>
				</td>
				<td><?php echo $row['withdraw']; ?> </td>
					<td>
						<?php
							$real_date = date("Y-m-d h:i:sa");
							
							if($real_date >= $row['due_date'])
							{
								
								?>
							<form action="" method="post">
								<input type="hidden" name="uid" value="<?php echo $row['invest_id']; ?>" >
								<input type="hidden" name="pay" value="PAY">
								<button name="subm" class="btn btn-danger">PAY</button>
							</form>
						<?php
							}else{
								?>
									<button class="btn btn-primary">WAIT</button>
								
							<?php
							}
						?>
					</td>
					<td> <div class="table-data-feature">
						<a href="home.php?einvest=<?php echo $row['invest_id']; ?>" class="btn btn-primary"><i class="fa fa-edit "></i></a>
                     </div> 
					 </td>
					 <td> <div class="table-data-feature">
						<a href="home.php?delete_in=<?php echo $row['invest_id']; ?>" class="btn btn-primary"><i class="fa fa-trash-o "></i></a>
                     </div> 
					 </td>
                    </tr>
                <?php
			}
		}
		else
		{
			?>
            <tr>
            <td>Nothing here...</td>
            </tr>
            <?php
		}
		
	}
	
	public function paging($query,$records_per_page)
	{
		$starting_position=0;
		if(isset($_GET["page_no"]))
		{
			$starting_position=($_GET["page_no"]-1)*$records_per_page;
		}
		$query2=$query." limit $starting_position,$records_per_page";
		return $query2;
	}
	
	public function paginglink($query,$records_per_page)
	{
		
		$self = $_SERVER['PHP_SELF'];
		
		$stmt = $this->db->prepare($query);
		$stmt->execute();
		
		$total_no_of_records = $stmt->rowCount();
		
		if($total_no_of_records > 0)
		{
			?><ul class="pagination"><?php
			$total_no_of_pages=ceil($total_no_of_records/$records_per_page);
			$current_page=1;
			if(isset($_GET["page_no"]))
			{
				$current_page=$_GET["page_no"];
			}
			if($current_page!=1)
			{
				$previous =$current_page-1;
				echo "<li class='page-item'><a class= 'page-link'  href='".$self."?page_no=1'>First</a></li>";
				echo "<li class='page-item'><a class= 'page-link' href='".$self."?page_no=".$previous."'>Previous</a></li>";
			}
			for($i=1;$i<=$total_no_of_pages;$i++)
			{
				if($i==$current_page)
				{
					echo "<li class='page-item'><a class= 'page-link' href='".$self."?page_no=".$i."' style='color:red;'>".$i."</a></li>";
				}
				else
				{
					echo "<li class='page-item'><a class= 'page-link' href='".$self."?page_no=".$i."'>".$i."</a></li>";
				}
			}
			if($current_page!=$total_no_of_pages)
			{
				$next=$current_page+1;
				echo "<li class='page-item'><a class= 'page-link' href='".$self."?page_no=".$next."'>Next</a></li>";
				echo "<li class='page-item'><a class= 'page-link' href='".$self."?page_no=".$total_no_of_pages."'>Last</a></li>";
			}
			?></ul><?php
		}
	}
	
	/* paging */
	
}
