  <section class="banner_area">
            <div class="booking_table d_flex align-items-center">
            	<div class="overlay bg-parallax" data-stellar-ratio="0.9" data-stellar-vertical-offset="0" data-background=""></div>
				<div class="container">
			
                <div class="page-cover text-center">
				 <div style="margin-top: 5%;"></div>

				 <div class="container">
            <div class="row justify-content-between">
                <!-- Contact Form --> 
				 
				 <?php
					
					if(isset($_POST['btn-login']))
					{
						$check1 = $_POST['check1'];
						
						$stmt=$con->prepare("SELECT * FROM checker WHERE no1=:check1");
						$stmt->execute(array(":check1"=>$check1));
						// && $check2 == $vRow['no2'] && $check3 == $vRow['no3'] && $check4 == $vRow['no4']
						$vRow=$stmt->fetch(PDO::FETCH_ASSOC);
						
						//echo "<h2>".$vRow['no2']."</h2><br>";
						//echo "<h2>".$check2."</h2>";
						if($check1 == $vRow['no1'])
						{
						//echo $no1 = $vRow['no1']."<br>";
						//echo $no2 = $vRow['no2']."<br>";
						//echo $no3 = $vRow['no3']."<br>";
						//echo $no4 = $vRow['no4']."<br>";
						echo "<script> alert('Ticket is valid, please contact our payment department !') </script>";
						}else{
							echo "<script> alert('Error Code !!!') </script>";
						}
					}
				 ?>
  <div class="col-lg-12 mb-6 order-lg-12" style="margin-top: -10%;">
            <div class="container">
				<div class="table-responsive table--no-card m-b-30"  >
	<table class="table table-striped table-bordered table-condensed table-opacity" >
	<tr>
		<td>
			
							<h3 style="color: #fff; margin-top: 5%">WINNING NUMBER</h3><hr />
							
			
						<form class="form-signin" method="post" id="login-form">
						
							<div id="error">
							<?php
								if(isset($error))
								{
									?>
									<div class="alert alert-danger">
									<i class="glyphicon glyphicon-warning-sign"></i> &nbsp; <?php echo $error; ?> !
									</div>
									<?php
								}
								
							?>
							</div>
							
							<div class="form-group">
								<input type="text" style="text-align: center; width: 50%; border: none; border-radius: 20px 20px;" name="check1" min="0" max="99" required />
							
							<span id="check-e"></span><br><br>
							<button type="submit" name="btn-login" class="btn btn-default">
										<i class="glyphicon glyphicon-log-in"></i> &nbsp; CHECK NO
								</button>
							</div>
						</form>
			</td>
		</tr>
	</table>
	
</div>
</div>
</div></div></div>
 <div class="container">
            <div class="row justify-content-between">
                <!-- Contact Form --> 
<div class="col-lg-6 mb-6 order-lg-2">
            <div class="container">
				<div class="table-responsive table--no-card m-b-30"  >
<table class="table table-striped table-bordered table-condensed table-opacity" style="color: #fff;">
	<tr>
		<td>
			<h3><i>HOW TO PLAY</i></h3>
			<p>Pick 3 from our out box figures, on our pages and if you are lucky to pick our our
			3 winning numbers you will be given our daily amount, you can below free or with $20 SteamCard.</p><br>
			<a href="#" class="btn btn-success">PLAY</a>
		</td>
	</tr>
</table>
</div>
</div>
</div>
<div class="col-lg-6 mb-6 order-lg-2">
            <div class="container">
				<div class="table-responsive table--no-card m-b-30"  >
<table class="table table-striped table-bordered table-condensed table-opacity" style="color: #fff;">
	
	<!--- Here our php comes to call our numbers from the database table	-->
	<?php
	$stmt=$con->prepare("SELECT * FROM random limit 4");
			$stmt->execute();
			
			// we use while loop to output all the data from the database
			while($IRow=$stmt->fetch(PDO::FETCH_ASSOC))
			{
			
			?>
			<tr>
		<td>
			<input type="text" value="<?php echo $IRow['ran1']; ?>" style="text-align: center; background: white; width: 20%; border: none; border-radius: 20px 20px;" disabled />
			<input type="text" value="<?php echo $IRow['ran2']; ?>" style="text-align: center; background: white; width: 20%; border: none; border-radius: 20px 20px;" disabled />
			<input type="text" value="<?php echo $IRow['ran3']; ?>" style="text-align: center; background: white; width: 20%; border: none; border-radius: 20px 20px;" disabled />
			<input type="text" value="<?php echo $IRow['ran4']; ?>" style="text-align: center; background: white; width: 20%; border: none; border-radius: 20px 20px;" disabled />
			
		</td>
		</tr>
		<?php
		}
			
			?>
	
</table>
</div>
</div>
</div>
</div>
</div>


				
					</div>
				</div>
            </div>
        </section>