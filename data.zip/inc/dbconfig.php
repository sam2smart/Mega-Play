<?php
// We create database connection 
	$con= new PDO("mysql:host=localhost;dbname=megaplay","root","");
	
?>